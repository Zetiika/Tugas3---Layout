
import java.awt.*;
import javax.swing.*;


public class Swing extends JFrame {
    JButton ok;
    JLabel judul,nama,nim,jk,agama,alamat;
    TextField uname,unim,addres;
    JRadioButton L,P;
    JComboBox cbReligion;
    String[] religion = {"Islam", "Kristen", "Hindu", "Budha"};
 
    //text untuk addres
    
    public void Mahasiswa(){
        setTitle ("Form Data Mahasiswa");
        judul = new JLabel ("Data Mahasiswa");
        nama = new JLabel ("Nama");
        uname = new TextField();
        nim = new JLabel ("Nim");
        unim = new TextField();
        jk = new JLabel ("Jenis Kelamin");
        L = new JRadioButton ("L");
        P = new JRadioButton ("P");
        agama = new JLabel ("Agama");
        cbReligion = new JComboBox(religion);
        alamat = new JLabel ("Alamat");
        addres = new TextField ();
        ok = new JButton("OK");
    
        
        
        setLayout (null);
        add(judul);
        add(nama);
        add(uname);
        add(nim);
        add(unim);
        add(jk);
        add(L);
        add(P);
        add(agama);
        add(cbReligion);
        add(alamat);
        add(addres);
        add(ok);        
        
        judul.setBounds(400, 100, 300, 30);
        nama.setBounds(50, 60, 100, 20);
        uname.setBounds(150, 60, 150, 20);
        nim.setBounds(50,100 , 100, 20);
        unim.setBounds(150, 100, 150, 20);
        jk.setBounds(50, 130, 80, 20);
        L.setBounds(150, 130, 40, 20);
        P.setBounds(200, 130, 40, 20);
        agama.setBounds(50, 160, 100, 20);
        cbReligion.setBounds(150, 150, 130, 30);
        alamat.setBounds(50, 190, 80, 20);
        addres.setBounds(150, 190, 150, 80);
        judul.setBounds(250, 300, 60, 20);
        ok.setBounds(250, 300, 60, 20);
        
        setSize(420,400);
        setVisible(true);
        SetDefaultCloseOperation(EXIT_ON_CLOSE);
     
        
        
    }

    private void SetDefaultCloseOperation(int EXIT_ON_CLOSE) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
}
