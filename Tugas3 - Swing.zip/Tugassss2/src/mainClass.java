
public class mainClass {

    
    public static void main(String[] args) {
        Swing Form = new Swing();
        Form.Mahasiswa();
    }
    
}
